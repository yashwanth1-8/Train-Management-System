import streamlit as st
import subprocess
import sys
import os
from datetime import datetime
import json

# Define the Train Management System with all required DSA structures in Python
class TrainManagementSystem:
    def __init__(self):
        # 1. Vector (list) for train storage
        self.trains = []
        
        # 2. Linked list for bookings
        self.bookings_head = None
        
        # 3. Stack for cancellation undo
        self.cancellation_stack = []
        
        # 4. Queue for waiting list
        self.waiting_list = []
        
        # 5. Priority queue for scheduling (using a sorted list to simulate)
        self.schedule_queue = []
        
        # 6. Graph for routes
        self.route_graph = {}
        
        # Initialize with some sample data
        self._initialize_sample_data()
    
    def _initialize_sample_data(self):
        """Initialize with sample train data"""
        sample_trains = [
            {"train_id": 101, "name": "Rajdhani Express", "from": "New Delhi", "to": "Mumbai", 
             "departure": "08:00", "arrival": "16:00", "duration": 480, "base_fare": 2500.00,
             "availability": {"SL": 50, "3A": 30, "2A": 20, "1A": 10, "CC": 40}},
            {"train_id": 102, "name": "Shatabdi Express", "from": "New Delhi", "to": "Chandigarh", 
             "departure": "06:00", "arrival": "09:30", "duration": 210, "base_fare": 1200.00,
             "availability": {"SL": 40, "3A": 25, "2A": 15, "1A": 5, "CC": 35}},
            {"train_id": 103, "name": "Duronto Express", "from": "Mumbai", "to": "New Delhi", 
             "departure": "22:00", "arrival": "08:00", "duration": 600, "base_fare": 3000.00,
             "availability": {"SL": 45, "3A": 28, "2A": 18, "1A": 8, "CC": 38}},
            {"train_id": 104, "name": "Mumbai Mail", "from": "Mumbai", "to": "New Delhi", 
             "departure": "21:30", "arrival": "08:15", "duration": 645, "base_fare": 1800.00,
             "availability": {"SL": 55, "3A": 35, "2A": 25, "1A": 12, "CC": 42}},
            {"train_id": 105, "name": "Kolkata Mail", "from": "Howrah", "to": "New Delhi", 
             "departure": "18:00", "arrival": "09:10", "duration": 910, "base_fare": 1600.00,
             "availability": {"SL": 60, "3A": 40, "2A": 22, "1A": 15, "CC": 45}},
            {"train_id": 106, "name": "Chennai Mail", "from": "Chennai", "to": "New Delhi", 
             "departure": "19:00", "arrival": "12:20", "duration": 1040, "base_fare": 1750.00,
             "availability": {"SL": 58, "3A": 38, "2A": 24, "1A": 14, "CC": 48}},
            {"train_id": 107, "name": "Bangalore Express", "from": "Bangalore", "to": "Mumbai", 
             "departure": "20:45", "arrival": "14:30", "duration": 1065, "base_fare": 1400.00,
             "availability": {"SL": 52, "3A": 32, "2A": 26, "1A": 16, "CC": 44}},
            {"train_id": 108, "name": "Goa Express", "from": "Mumbai", "to": "Goa", 
             "departure": "07:00", "arrival": "13:45", "duration": 405, "base_fare": 1100.00,
             "availability": {"SL": 48, "3A": 28, "2A": 18, "1A": 8, "CC": 36}},
            {"train_id": 109, "name": "Hyderabad Express", "from": "Secunderabad", "to": "Mumbai", 
             "departure": "22:30", "arrival": "08:15", "duration": 585, "base_fare": 1300.00,
             "availability": {"SL": 53, "3A": 33, "2A": 21, "1A": 11, "CC": 41}},
            {"train_id": 110, "name": "Ahmedabad Express", "from": "Mumbai", "to": "Ahmedabad", 
             "departure": "23:15", "arrival": "06:30", "duration": 435, "base_fare": 900.00,
             "availability": {"SL": 45, "3A": 25, "2A": 15, "1A": 7, "CC": 35}},
            {"train_id": 111, "name": "Pune Express", "from": "Mumbai", "to": "Pune", 
             "departure": "06:30", "arrival": "09:15", "duration": 165, "base_fare": 350.00,
             "availability": {"SL": 40, "3A": 20, "2A": 10, "1A": 5, "CC": 30}},
            {"train_id": 112, "name": "Jaipur Express", "from": "Delhi", "to": "Jaipur", 
             "departure": "23:45", "arrival": "06:30", "duration": 405, "base_fare": 450.00,
             "availability": {"SL": 35, "3A": 18, "2A": 12, "1A": 6, "CC": 28}},
            {"train_id": 113, "name": "Patna Express", "from": "New Delhi", "to": "Patna", 
             "departure": "17:30", "arrival": "08:15", "duration": 885, "base_fare": 1200.00,
             "availability": {"SL": 42, "3A": 22, "2A": 14, "1A": 8, "CC": 32}},
            {"train_id": 114, "name": "Lucknow Express", "from": "New Delhi", "to": "Lucknow", 
             "departure": "05:30", "arrival": "12:15", "duration": 405, "base_fare": 750.00,
             "availability": {"SL": 38, "3A": 24, "2A": 16, "1A": 9, "CC": 34}},
            {"train_id": 115, "name": "Varanasi Express", "from": "New Delhi", "to": "Varanasi", 
             "departure": "20:15", "arrival": "06:45", "duration": 630, "base_fare": 950.00,
             "availability": {"SL": 46, "3A": 26, "2A": 17, "1A": 10, "CC": 39}}
        ]
        
        for train in sample_trains:
            self.add_train(train)
    
    # 1. Vector operations for train storage
    def add_train(self, train_data):
        self.trains.append(train_data)
        # Keep sorted by train_id for binary search
        self.trains.sort(key=lambda x: x['train_id'])
    
    def get_all_trains(self):
        return self.trains
    
    # 2. Binary search for train lookup
    def binary_search_train(self, train_id):
        left, right = 0, len(self.trains) - 1
        while left <= right:
            mid = (left + right) // 2
            if self.trains[mid]['train_id'] == train_id:
                return mid
            elif self.trains[mid]['train_id'] < train_id:
                left = mid + 1
            else:
                right = mid - 1
        return -1
    
    def get_train_by_id(self, train_id):
        idx = self.binary_search_train(train_id)
        if idx != -1:
            return self.trains[idx]
        return None
    
    # 3. Linked list node for bookings
    class BookingNode:
        def __init__(self, booking_data):
            self.booking = booking_data
            self.next = None
    
    def add_booking(self, booking_data):
        new_node = self.BookingNode(booking_data)
        new_node.next = self.bookings_head
        self.bookings_head = new_node
    
    def get_all_bookings(self):
        bookings = []
        current = self.bookings_head
        while current:
            bookings.append(current.booking)
            current = current.next
        return bookings
    
    # 4. Stack operations for cancellation undo
    def push_to_cancellation_stack(self, booking_id):
        self.cancellation_stack.append(booking_id)
    
    def pop_from_cancellation_stack(self):
        if self.cancellation_stack:
            return self.cancellation_stack.pop()
        return None
    
    # 5. Queue operations for waiting list
    def enqueue_waiting_list(self, user_id, coach_type):
        self.waiting_list.append((user_id, coach_type))
    
    def dequeue_waiting_list(self):
        if self.waiting_list:
            return self.waiting_list.pop(0)
        return None
    
    # 6. Priority queue simulation for scheduling
    def add_to_schedule_queue(self, priority, train_id):
        self.schedule_queue.append((priority, train_id))
        self.schedule_queue.sort()  # Keep sorted to simulate priority queue
    
    def get_next_scheduled_train(self):
        if self.schedule_queue:
            return self.schedule_queue.pop(0)
        return None
    
    # 7. Graph operations for routes
    def add_route_connection(self, from_station, to_station, distance):
        if from_station not in self.route_graph:
            self.route_graph[from_station] = []
        self.route_graph[from_station].append({"to": to_station, "distance": distance})
    
    # Additional functionality methods
    def search_trains(self, from_station, to_station, max_duration=None, min_fare=None, max_fare=None):
        results = []
        for train in self.trains:
            # Basic route match
            from_match = from_station.lower() in train['from'].lower() or train['from'].lower() in from_station.lower()
            to_match = to_station.lower() in train['to'].lower() or train['to'].lower() in to_station.lower()
            
            if from_match and to_match:
                # Apply additional filters if provided
                duration_ok = max_duration is None or train['duration'] <= max_duration
                fare_ok = True
                if min_fare is not None:
                    fare_ok = fare_ok and train['base_fare'] >= min_fare
                if max_fare is not None:
                    fare_ok = fare_ok and train['base_fare'] <= max_fare
                
                if duration_ok and fare_ok:
                    results.append(train)
        return results
    
    def check_seat_availability(self, train_id, coach_type):
        train = self.get_train_by_id(train_id)
        if train and coach_type in train['availability']:
            return train['availability'][coach_type] > 0
        return False
    
    def get_pnr_status(self, pnr):
        # Find booking by PNR
        current = self.bookings_head
        while current:
            if current.booking.get('pnr') == pnr:
                return current.booking
            current = current.next
        return None
    
    def book_ticket(self, user_id, train_id, passenger_name, berth_preference, coach_type, fare):
        train_idx = self.binary_search_train(train_id)
        if train_idx == -1:
            return {"success": False, "message": f"Train with ID {train_id} not found."}
        
        train = self.trains[train_idx]
        if train['availability'][coach_type] > 0:
            # Allocate seat
            self.trains[train_idx]['availability'][coach_type] -= 1
            
            # Generate booking ID
            booking_id = 1000 + len(self.get_all_bookings()) + 1
            
            # Calculate seat number based on remaining seats
            seat_number = 50 - self.trains[train_idx]['availability'][coach_type]  # Assuming 50 max seats
            
            # Create booking
            booking_data = {
                "booking_id": booking_id,
                "user_id": user_id,
                "train_id": train_id,
                "passenger_name": passenger_name,
                "berth_preference": berth_preference,
                "coach_type": coach_type,
                "seat_number": seat_number,
                "status": "CONFIRMED",
                "total_fare": fare,
                "booking_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "pnr": f"{train_id}{booking_id}"
            }
            
            self.add_booking(booking_data)
            return {"success": True, "message": f"Booking successful! Booking ID: {booking_id}, PNR: {booking_data['pnr']}", "booking_id": booking_id, "pnr": booking_data['pnr']}
        else:
            # Add to waiting list
            self.enqueue_waiting_list(user_id, coach_type)
            return {"success": False, "message": f"No seats available in {coach_type}. Added to waiting list."}
    
    def cancel_ticket(self, booking_id):
        current = self.bookings_head
        prev = None
        
        while current:
            if current.booking['booking_id'] == booking_id:
                # Add to cancellation stack
                self.push_to_cancellation_stack(booking_id)
                
                # Update train availability
                train_idx = self.binary_search_train(current.booking['train_id'])
                if train_idx != -1:
                    train = self.trains[train_idx]
                    train['availability'][current.booking['coach_type']] += 1
                
                # Remove from linked list
                if prev is None:
                    self.bookings_head = current.next
                else:
                    prev.next = current.next
                
                return {"success": True, "message": f"Booking with ID {booking_id} cancelled successfully."}
            
            prev = current
            current = current.next
        
        return {"success": False, "message": f"Booking with ID {booking_id} not found."}

# Initialize system in session state
if 'train_system' not in st.session_state:
    st.session_state.train_system = TrainManagementSystem()

system = st.session_state.train_system

# Streamlit UI - Dark Theme
st.set_page_config(page_title="Dark Train Dashboard", page_icon="🚂", layout="wide")

# Custom CSS for dark theme
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Merriweather:wght@400;700&display=swap');

    body {
        background-color: #121212;
        color: #ffffff;
        font-family: 'Merriweather', serif;
    }
    
    [data-testid=stSidebar] {
        background-color: #1e1e1e;
    }
    
    [data-testid=stHeader] {
        background-color: rgba(18, 18, 18, 0.8);
    }
    
    [data-testid=stToolbar] {
        background-color: #121212;
    }
    
    h1, h2, h3, h4, h5, h6 {
        color: white;
    }
    
    /* Metric card styles */
    .metric-card {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        padding: 15px;
        margin: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .metric-value {
        font-size: 2.5rem;
        font-weight: bold;
        color: white;
        margin-bottom: 5px;
        text-align: center;
    }
    
    .metric-label {
        font-size: 1rem;
        color: #a0c4ff;
        font-weight: 500;
        text-align: center;
    }
    
    /* Button styles */
    .stButton>button {
        background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        font-family: 'Merriweather', serif;
        transition: all 0.3s ease;
    }
    
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.2);
        background: linear-gradient(135deg, #34495e 0%, #2980b9 100%);
    }
    
    /* Input fields */
    .stSelectbox>div>div, .stTextInput>div>div, .stNumberInput>div>div {
        background-color: #2d2d2d;
        color: white;
        border: 2px solid #3498db;
        border-radius: 8px;
    }
    
    /* Expander */
    [data-testid="stExpander"] {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 10px;
        border: 1px solid #3498db;
    }
    
    /* Container */
    .st-emotion-cache-16txtl3 {
        color: white;
    }
    
    .st-emotion-cache-1dtejc0 {
        color: white;
    }
</style>
""", unsafe_allow_html=True)

st.title("🚂 Dark Train Management Dashboard")

# Sidebar with dark theme
with st.sidebar:
    st.header("🧭 Navigation")
    page = st.selectbox("Choose a function:", 
                       ["🏠 Home", "🚆 View Trains", "🔍 Search Trains", "🎫 Book Ticket", 
                        "❌ Cancel Ticket", "📋 PNR Status", "💰 Refund Status", "📝 View Bookings", "🕐 Waiting List", 
                        "ℹ️ System Info"])

if page == "🏠 Home":
    st.markdown('<div style="padding: 20px;"><h1>Welcome to the Train Management System! 🚂</h1></div>', unsafe_allow_html=True)
    
    # Attractive welcome section
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.1); padding: 20px; border-radius: 15px; border-left: 5px solid #3498db;">
    This system implements various Data Structures and Algorithms:
    
    - **<span style="color: #a0c4ff;">Vector (List)</span>**: For train storage
    - **<span style="color: #a0c4ff;">Binary Search</span>**: For fast train lookup
    - **<span style="color: #a0c4ff;">Linked List</span>**: For managing bookings
    - **<span style="color: #a0c4ff;">Stack</span>**: For cancellation undo functionality
    - **<span style="color: #a0c4ff;">Queue</span>**: For managing waiting lists
    - **<span style="color: #a0c4ff;">Priority Queue</span>**: For scheduling
    - **<span style="color: #a0c4ff;">Graph</span>**: For route management
    
    Select a function from the sidebar to get started!
    </div>
    """, unsafe_allow_html=True)
    
    # System statistics with dark theme metrics
    st.markdown('<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif; margin-top: 20px;">System Statistics 📊</h3>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        with st.container():
            st.markdown(f"""<div class='metric-card'>
                <div class='metric-value'>{len(system.get_all_trains())}</div>
                <div class='metric-label'>🚂 Total Trains</div>
            </div>""", unsafe_allow_html=True)
    with col2:
        with st.container():
            st.markdown(f"""<div class='metric-card'>
                <div class='metric-value'>{len(system.get_all_bookings())}</div>
                <div class='metric-label'>🎫 Total Bookings</div>
            </div>""", unsafe_allow_html=True)
    with col3:
        with st.container():
            st.markdown(f"""<div class='metric-card'>
                <div class='metric-value'>{len(system.waiting_list)}</div>
                <div class='metric-label'>🕐 Waiting List</div>
            </div>""", unsafe_allow_html=True)
    
    # Feature highlights
    st.markdown('<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif; margin-top: 20px;">Key Features 🌟</h3>', unsafe_allow_html=True)
    features = [
        ("🔍 Real-time Search", "Find trains instantly with our optimized search algorithm"),
        ("🎫 Easy Booking", "Simple and secure ticket booking process"),
        ("📋 PNR Status", "Track your booking status in real-time"),
        ("💰 Refund Status", "Check refund status with transparency")
    ]
    
    for feature, desc in features:
        with st.container():
            st.markdown(f"<div class='metric-card'><b style='color:white;'>{feature}</b><br><small style='color:#a0c4ff;'>{desc}</small></div>", unsafe_allow_html=True)

elif page == "🚆 View Trains":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Train Schedule 🚆</h1>', unsafe_allow_html=True)
    st.markdown('<h2 style="color: #3498db; font-family: &quot;Merriweather&quot;, serif;">All Available Trains</h2>', unsafe_allow_html=True)
    
    if st.button("🔄 Refresh Train List"):
        trains = system.get_all_trains()
        if trains:
            # Filter options
            st.markdown('<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Filter Trains 🔍</h3>', unsafe_allow_html=True)
            col1, col2, col3 = st.columns(3)
            with col1:
                max_fare = st.slider("Max Fare", 0, 5000, 3000)
            with col2:
                min_seats = st.slider("Min Seats Available", 0, 20, 5)
            with col3:
                coach_types = st.multiselect("Coach Types", ["SL", "3A", "2A", "1A", "CC"], default=["SL", "3A", "2A"])
            
            filtered_trains = []
            for train in trains:
                # Apply filters
                has_available_seats = any(train['availability'][ct] >= min_seats for ct in coach_types)
                if train['base_fare'] <= max_fare and has_available_seats:
                    filtered_trains.append(train)
            
            st.markdown(f'<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Showing {len(filtered_trains)} of {len(trains)} trains 📊</h3>', unsafe_allow_html=True)
            
            for train in filtered_trains:
                with st.container():
                    st.markdown(f"<div style='background: rgba(255, 255, 255, 0.1); border-radius: 12px; padding: 15px; margin: 10px 0; border-left: 5px solid #3498db; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'><h4 style='color: white;'>🚄 {train['name']} (Train #{train['train_id']})</h4>", unsafe_allow_html=True)
                    col1, col2, col3 = st.columns([2, 2, 1])
                    with col1:
                        st.write(f"**Origin:** <span style='color: #a0c4ff;'>{train['from']}</span>", unsafe_allow_html=True)
                        st.write(f"**Destination:** <span style='color: #a0c4ff;'>{train['to']}</span>", unsafe_allow_html=True)
                    with col2:
                        st.write(f"🕐 {train['departure']} → {train['arrival']}")
                        st.write(f"⏱️ Duration: {train['duration']//60}h {train['duration']%60}m")
                    with col3:
                        st.markdown(f"<div style='color: white; font-size: 1.2em; font-weight: bold;'>Fare: ₹{train['base_fare']:.0f}</div>", unsafe_allow_html=True)
                    
                    # Availability with color coding
                    st.write("**Seat Availability:**")
                    cols = st.columns(len(train['availability']))
                    for i, (cls, count) in enumerate(train['availability'].items()):
                        if cls in coach_types:
                            color = "#90EE90" if count > 10 else "#FFA500" if count > 0 else "#FF6B6B"
                            cols[i].markdown(f"<div style='background-color:{color}; padding:10px; border-radius:5px; text-align:center; color: black; font-weight: bold;'>{cls}<br><strong>{count}</strong></div>", unsafe_allow_html=True)
                        else:
                            cols[i].markdown(f"<div style='background-color:#555555; padding:10px; border-radius:5px; text-align:center; opacity:0.5; color: #aaa;'>{cls}<br>{count}</div>", unsafe_allow_html=True)
                    st.markdown("</div>", unsafe_allow_html=True)
                    st.divider()
        else:
            st.info("No trains available.")

elif page == "🔍 Search Trains":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Search for Trains 🚂</h1>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        from_station = st.text_input("From Station", placeholder="e.g., New Delhi")
    with col2:
        to_station = st.text_input("To Station", placeholder="e.g., Mumbai")
    
    if st.button("🔍 Search Trains"):
        if from_station and to_station:
            # Advanced search parameters
            max_dur = st.slider("Max Duration (min)", 0, 2000, 2000)
            max_fare = st.slider("Max Fare", 0, 5000, 5000)
            
            results = system.search_trains(from_station, to_station, max_duration=max_dur, max_fare=max_fare)
            if results:
                st.success(f"Found {len(results)} train(s)")
                
                # Sort by fare
                results.sort(key=lambda x: x['base_fare'])
                
                for train in results:
                    with st.container():
                        st.markdown(f"<div style='background: rgba(255, 255, 255, 0.1); border-radius: 12px; padding: 15px; margin: 10px 0; border-left: 5px solid #3498db; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'><h4 style='color: white;'>🚄 {train['name']} (#{train['train_id']})</h4>", unsafe_allow_html=True)
                        col1, col2, col3, col4 = st.columns(4)
                        with col1:
                            st.write(f"**出发:** <span style='color: #a0c4ff;'>{train['from']}</span>", unsafe_allow_html=True)
                            st.write(f"**到达:** <span style='color: #a0c4ff;'>{train['to']}</span>", unsafe_allow_html=True)
                        with col2:
                            st.write(f"🕐 {train['departure']} → {train['arrival']}")
                            st.write(f"⏱️ Duration: {train['duration']//60}h {train['duration']%60}m")
                        with col3:
                            st.markdown(f"<div style='color: white; font-size: 1.2em; font-weight: bold;'>Fare: ₹{train['base_fare']:.0f}</div>", unsafe_allow_html=True)
                        with col4:
                            # Show availability with color coding
                            available_classes = [cls for cls, count in train['availability'].items() if count > 0]
                            if available_classes:
                                st.success(f"✅ {len(available_classes)} classes available")
                            else:
                                st.error("❌ No seats available")
                        
                        # Detailed availability
                        st.write("**Seat Availability:**")
                        cols = st.columns(len(train['availability']))
                        for i, (cls, count) in enumerate(train['availability'].items()):
                            color = "#90EE90" if count > 10 else "#FFA500" if count > 0 else "#FF6B6B"
                            cols[i].markdown(f"<div style='background-color:{color}; padding:8px; border-radius:4px; text-align:center; font-weight:bold; color: black;'>{cls}<br>{count}</div>", unsafe_allow_html=True)
                        
                        # Quick book button
                        if st.button(f"Quick Book - {train['train_id']}", key=f"qb_{train['train_id']}"):
                            st.session_state.quick_book_train = train['train_id']
                            st.rerun()
                        
                        st.markdown("</div>", unsafe_allow_html=True)
                        st.divider()
            else:
                st.warning("No trains found for the given route.")
                # Suggest alternatives
                all_trains = system.get_all_trains()
                from_matches = [t for t in all_trains if from_station.lower() in t['from'].lower()]
                to_matches = [t for t in all_trains if to_station.lower() in t['to'].lower()]
                
                if from_matches:
                    st.info(f"Trains from nearby stations to '{to_station}': {len(from_matches)} found")
                if to_matches:
                    st.info(f"Trains from '{from_station}' to nearby stations: {len(to_matches)} found")
        else:
            st.warning("Please enter both source and destination stations.")

elif page == "🎫 Book Ticket":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Book a Ticket 🎫</h1>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        user_id = st.number_input("User ID", min_value=1, value=1001)
        train_id = st.number_input("Train ID", min_value=1, value=101)
        passenger_name = st.text_input("Passenger Name", placeholder="Enter passenger name")
    
    with col2:
        berth_pref = st.selectbox("Berth Preference", ["Lower", "Middle", "Upper", "Side Lower", "Side Upper"])
        coach_type = st.selectbox("Coach Type", ["SL", "3A", "2A", "1A", "CC"])
        fare = st.number_input("Fare", min_value=0.0, value=1000.0, step=100.0)
    
    if st.button("🎫 Book Ticket"):
        if passenger_name:
            result = system.book_ticket(user_id, train_id, passenger_name, berth_pref, coach_type, fare)
            if result['success']:
                st.success(result['message'])
            else:
                st.warning(result['message'])
        else:
            st.warning("Please enter passenger name.")

elif page == "❌ Cancel Ticket":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Cancel Ticket ❌</h1>', unsafe_allow_html=True)
    
    booking_id = st.number_input("Booking ID to Cancel", min_value=1, value=1001)
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("❌ Cancel Ticket"):
            result = system.cancel_ticket(booking_id)
            if result['success']:
                st.success(result['message'])
            else:
                st.error(result['message'])
    
    with col2:
        if st.button("↩️ Undo Cancellation"):
            undone_booking = system.pop_from_cancellation_stack()
            if undone_booking:
                st.info(f"Undid cancellation for booking ID: {undone_booking}")
            else:
                st.warning("No cancellations to undo.")

elif page == "📋 PNR Status":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">PNR Status Inquiry 📋</h1>', unsafe_allow_html=True)
    
    pnr_input = st.text_input("Enter PNR Number", placeholder="e.g., 1011001")
    
    if st.button("🔍 Check PNR Status"):
        if pnr_input:
            booking = system.get_pnr_status(pnr_input)
            if booking:
                st.success("PNR Status Found!")
                
                # Get train details
                train = system.get_train_by_id(booking['train_id'])
                
                st.markdown(f"<div style='background: rgba(255, 255, 255, 0.1); border-radius: 12px; padding: 15px; margin: 10px 0; border-left: 5px solid #3498db; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'><h4 style='color: white;'>PNR: {booking['pnr']} | Status: {booking['status']}</h4>", unsafe_allow_html=True)
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.write(f"**Passenger:** <span style='color: #a0c4ff;'>{booking['passenger_name']}</span>", unsafe_allow_html=True)
                    st.write(f"**User ID:** <span style='color: #a0c4ff;'>{booking['user_id']}</span>", unsafe_allow_html=True)
                    st.write(f"**Booking ID:** <span style='color: #a0c4ff;'>{booking['booking_id']}</span>", unsafe_allow_html=True)
                with col2:
                    st.write(f"**Train:** <span style='color: #a0c4ff;'>{booking['train_id']} - {train['name'] if train else 'Unknown'}</span>", unsafe_allow_html=True)
                    st.write(f"**Route:** <span style='color: #a0c4ff;'>{train['from'] if train else 'Unknown'} → {train['to'] if train else 'Unknown'}</span>", unsafe_allow_html=True)
                    st.write(f"**Date:** <span style='color: #a0c4ff;'>{booking['booking_date']}</span>", unsafe_allow_html=True)
                with col3:
                    st.write(f"**Coach:** <span style='color: #a0c4ff;'>{booking['coach_type']}</span>", unsafe_allow_html=True)
                    st.write(f"**Seat:** <span style='color: #a0c4ff;'>{booking['seat_number']}</span>", unsafe_allow_html=True)
                    st.write(f"**Fare:** <span style='color: #a0c4ff;'>₹{booking['total_fare']:.0f}</span>", unsafe_allow_html=True)
                
                # Journey details
                if train:
                    st.subheader("Journey Details")
                    st.write(f"📅 Travel Date: {booking['booking_date'][:10]}")
                    st.write(f"🕐 Departure: {train['departure']} from {train['from']}")
                    st.write(f"🕐 Arrival: {train['arrival']} at {train['to']}")
                    st.write(f"⏱️ Duration: {train['duration']//60}h {train['duration']%60}m")
                st.markdown("</div>", unsafe_allow_html=True)
            else:
                st.error(f"PNR {pnr_input} not found. Please check the number and try again.")
        else:
            st.warning("Please enter a PNR number.")
    
    # Sample PNRs for testing
    st.info("💡 Tip: You can check PNRs generated from your bookings")

elif page == "💰 Refund Status":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Refund Status Inquiry 💰</h1>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        booking_id = st.number_input("Enter Booking ID", min_value=1, value=1001)
    with col2:
        refund_type = st.selectbox("Refund Type", ["Full", "Partial", "Tatkal", "Premium Tatkal", "General"])
    
    if st.button("🔍 Check Refund Status"):
        # Simulate refund status check
        import random
        statuses = ["Processed", "Pending", "Initiated", "Rejected", "Delayed"]
        status = random.choice(statuses)
        refund_amount = random.uniform(500, 2500) if status != "Rejected" else 0
        
        st.markdown(f'<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Refund Status: {status}</h3>', unsafe_allow_html=True)
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f"<div style='color: white; font-size: 1.5em; font-weight: bold;'>Booking ID: {booking_id}</div>", unsafe_allow_html=True)
        with col2:
            st.markdown(f"<div style='color: white; font-size: 1.5em; font-weight: bold;'>Type: {refund_type}</div>", unsafe_allow_html=True)
        with col3:
            st.markdown(f"<div style='color: white; font-size: 1.5em; font-weight: bold;'>Amount: ₹{refund_amount:.0f}</div>", unsafe_allow_html=True)
        
        # Timeline
        if status == "Processed":
            st.success(f"Refund of ₹{refund_amount:.0f} has been processed successfully!")
            st.write("💳 Expected到账: Within 3-5 business days")
        elif status == "Pending":
            st.info("Refund is currently under review")
            st.progress(60)  # 60% progress
        elif status == "Initiated":
            st.info("Refund process has been initiated")
            st.progress(30)  # 30% progress
        elif status == "Delayed":
            st.warning("Refund process is delayed. Contact customer care.")
        else:  # Rejected
            st.error("Refund request has been rejected")
            st.write("📞 Contact: 139 or customer care for more details")
    
    # Recent refunds
    st.markdown('<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Recent Refund Activity</h3>', unsafe_allow_html=True)
    recent_refunds = [
        {"booking_id": 1005, "amount": 1800, "status": "Processed", "date": "2023-05-15"},
        {"booking_id": 1012, "amount": 1200, "status": "Pending", "date": "2023-05-16"},
        {"booking_id": 1023, "amount": 2500, "status": "Processed", "date": "2023-05-17"}
    ]
    
    for refund in recent_refunds:
        st.write(f"**Booking #{refund['booking_id']}**: ₹{refund['amount']:.0f} - {refund['status']} on {refund['date']}")

elif page == "📝 View Bookings":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">View All Bookings 📝</h1>', unsafe_allow_html=True)
    
    if st.button("🔄 Refresh Bookings"):
        bookings = system.get_all_bookings()
        if bookings:
            # Filter options for bookings
            st.markdown('<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Filter Bookings</h3>', unsafe_allow_html=True)
            col1, col2 = st.columns(2)
            with col1:
                status_filter = st.selectbox("Filter by Status", ["All", "CONFIRMED", "CANCELLED"])
            with col2:
                train_filter = st.selectbox("Filter by Train ID", ["All"] + sorted(list(set(str(b['train_id']) for b in bookings))))
            
            # Apply filters
            filtered_bookings = []
            for booking in bookings:
                status_match = status_filter == "All" or booking['status'] == status_filter
                train_match = train_filter == "All" or str(booking['train_id']) == str(train_filter)
                if status_match and train_match:
                    filtered_bookings.append(booking)
            
            st.success(f"Found {len(filtered_bookings)} booking(s)")
            
            for booking in filtered_bookings:
                with st.container():
                    st.markdown(f"<div style='background: rgba(255, 255, 255, 0.1); border-radius: 12px; padding: 15px; margin: 10px 0; border-left: 5px solid #3498db; box-shadow: 0 4px 8px rgba(0,0,0,0.1);'><h4 style='color: white;'>🎫 Booking #{booking['booking_id']} | PNR: {booking['pnr']}</h4>", unsafe_allow_html=True)
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.write(f"**👤 Passenger:** <span style='color: #a0c4ff;'>{booking['passenger_name']}</span>", unsafe_allow_html=True)
                        st.write(f"**🆔 User ID:** <span style='color: #a0c4ff;'>{booking['user_id']}</span>", unsafe_allow_html=True)
                    with col2:
                        st.write(f"**🚂 Train:** <span style='color: #a0c4ff;'>{booking['train_id']}</span>", unsafe_allow_html=True)
                        st.write(f"**🎫 Coach:** <span style='color: #a0c4ff;'>{booking['coach_type']}</span>", unsafe_allow_html=True)
                    with col3:
                        st.write(f"**💺 Seat:** <span style='color: #a0c4ff;'>{booking['seat_number']}</span>", unsafe_allow_html=True)
                        st.write(f"**🛏️ Berth:** <span style='color: #a0c4ff;'>{booking['berth_preference']}</span>", unsafe_allow_html=True)
                    with col4:
                        st.write(f"**💰 Fare:** <span style='color: #a0c4ff;'>₹{booking['total_fare']:.0f}</span>", unsafe_allow_html=True)
                        st.write(f"**📊 Status:** <span style='color: #a0c4ff;'>{booking['status']}</span>", unsafe_allow_html=True)
                    
                    st.write(f"📅 Booking Date: {booking['booking_date']}")
                    st.markdown("</div>", unsafe_allow_html=True)
                    st.divider()
        else:
            st.info("No bookings found.")

elif page == "🕐 Waiting List":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Waiting List Management 🕐</h1>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        user_id = st.number_input("User ID", min_value=1, value=1001)
    with col2:
        coach_type = st.selectbox("Coach Type", ["SL", "3A", "2A", "1A", "CC"], key="wl_coach")
    
    if st.button("➕ Add to Waiting List"):
        system.enqueue_waiting_list(user_id, coach_type)
        st.info(f"Added user {user_id} to waiting list for {coach_type}")
    
    if st.button("📋 View Waiting List"):
        if system.waiting_list:
            st.table([{"User ID": item[0], "Coach Type": item[1]} for item in system.waiting_list])
        else:
            st.info("Waiting list is empty.")

elif page == "ℹ️ System Info":
    st.markdown('<h1 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">System Information ℹ️</h1>', unsafe_allow_html=True)
    
    st.markdown('<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Data Structures Used:</h3>', unsafe_allow_html=True)
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 10px; border-left: 5px solid #3498db;">
    - **<span style="color: #a0c4ff;">Vector (List)</span>**: Stores train information efficiently
    - **<span style="color: #a0c4ff;">Linked List</span>**: Manages booking records dynamically
    - **<span style="color: #a0c4ff;">Stack</span>**: Implements undo functionality for cancellations
    - **<span style="color: #a0c4ff;">Queue</span>**: Handles waiting list processing (FIFO)
    - **<span style="color: #a0c4ff;">Priority Queue</span>**: Manages scheduling priorities
    - **<span style="color: #a0c4ff;">Graph</span>**: Represents route connections between stations
    - **<span style="color: #a0c4ff;">Binary Search</span>**: Provides O(log n) train lookup
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown('<h3 style="color: white; font-family: &quot;Playfair Display&quot;, serif;">Algorithms Implemented:</h3>', unsafe_allow_html=True)
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.1); padding: 15px; border-radius: 10px; border-left: 5px solid #e74c3c;">
    - **<span style="color: #a0c4ff;">Binary Search</span>**: Fast train ID lookup
    - **<span style="color: #a0c4ff;">Dynamic Memory Management</span>**: For linked structures
    - **<span style="color: #a0c4ff;">Sorting</span>**: Maintains ordered train list
    </div>
    """, unsafe_allow_html=True)
    
    with st.expander("Check Seat Availability"):
        train_id = st.number_input("Train ID", min_value=1, value=101, key="avail_train")
        coach_type = st.selectbox("Coach Type", ["SL", "3A", "2A", "1A", "CC"], key="avail_coach")
        
        if st.button("🔍 Check Availability", key="check_avail"):
            available = system.check_seat_availability(train_id, coach_type)
            if available:
                st.success(f"Seats ARE available for train {train_id} in {coach_type} class")
            else:
                st.error(f"No seats available for train {train_id} in {coach_type} class")

# Footer
st.markdown("---")
st.markdown('<div style="text-align: center; color: #a0c4ff; font-family: &quot;Merriweather&quot;, serif; font-size: 1.1em;">Built with ❤️ using Data Structures & Algorithms and Streamlit</div>', unsafe_allow_html=True)