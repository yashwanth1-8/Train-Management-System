# Train Management System

This is a comprehensive Train Management System implemented with Data Structures and Algorithms (DSA) concepts using both C++ and Python/Streamlit.

## Features

- **C++ Implementation**: Complete train management with all DSA structures
- **Vector Implementation**: Train storage using STL vectors
- **Binary Search**: Efficient train lookup by ID
- **Linked List**: Dynamic booking management
- **Stack**: Cancellation undo functionality
- **Queue**: Waiting list management (FIFO)
- **Priority Queue**: Scheduling functionality
- **Graph**: Route management between stations
- **Interactive Web Interface**: Built with Streamlit connecting to C++ backend

## Data Structures Used

1. **Vector**: For train storage - allows dynamic sizing and efficient access
2. **Linked List**: For booking management - enables dynamic insertion/deletion
3. **Stack**: For cancellation undo - LIFO structure for reverting cancellations
4. **Queue**: For waiting list - FIFO structure for fair processing
5. **Priority Queue**: For scheduling - prioritizes important tasks
6. **Graph**: For route representation - models connections between stations
7. **Binary Search**: For fast train lookup - O(log n) search complexity

## Files Included

- `train_management_system.cpp` - Complete C++ implementation with all DSA structures
- `train_app.py` - Streamlit web interface
- `requirements.txt` - Python dependencies

## How to Run

### Option 1: Web Interface (Recommended)
1. Make sure you have Python installed
2. Install dependencies: `pip install streamlit`
3. Run the application: `python -m streamlit run train_app.py`
4. Open your browser to http://localhost:8501

### Option 2: C++ Console Application
1. Compile the C++ code: `g++ -o train_system train_management_system.cpp`
2. Run with commands:
   - `./train_system display_trains` - Show all trains
   - `./train_system search_trains <from> <to>` - Search for trains
   - `./train_system book_ticket <user_id> <train_id> <name> <berth> <coach> <fare>` - Book a ticket
   - `./train_system cancel_ticket <booking_id>` - Cancel a ticket

## System Capabilities

- View all available trains
- Search trains by source and destination
- Book tickets with seat allocation
- Cancel bookings with undo functionality
- Manage waiting lists
- Check seat availability
- View booking history
- Interactive web-based UI

## Algorithms Implemented

- Binary search for efficient train lookup
- Sorting algorithms to maintain ordered data
- Dynamic memory management for linked structures
- Command-line argument processing