#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
#include <list>
#include <map>
#include <set>
#include <climits>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <cstdlib>

using namespace std;

// Structure for Train Information
struct Train {
    int trainId;
    string trainName;
    string fromStation;
    string toStation;
    string departureTime;
    string arrivalTime;
    int durationMinutes;
    double baseFare;
    map<string, int> availability; // Class -> Available seats
    
    Train(int id, string name, string from, string to, string dep, string arr, int dur, double fare) 
        : trainId(id), trainName(name), fromStation(from), toStation(to), 
          departureTime(dep), arrivalTime(arr), durationMinutes(dur), baseFare(fare) {
        // Initialize availability for different classes
        availability["SL"] = 50; // Sleeper
        availability["3A"] = 30; // Third AC
        availability["2A"] = 20; // Second AC
        availability["1A"] = 10; // First AC
        availability["CC"] = 40; // Chair Car
    }
    
    bool operator<(const Train& other) const {
        return trainId < other.trainId;
    }
};

// Structure for Booking
struct Booking {
    int bookingId;
    int userId;
    int trainId;
    string passengerName;
    string berthPreference;
    string coachType;
    int seatNumber;
    string status;
    double totalFare;
    string bookingDate;
    
    Booking(int bid, int uid, int tid, string name, string pref, string coach, int seat, string stat, double fare)
        : bookingId(bid), userId(uid), trainId(tid), passengerName(name), 
          berthPreference(pref), coachType(coach), seatNumber(seat), 
          status(stat), totalFare(fare) {
        time_t now = time(0);
        bookingDate = ctime(&now);
        bookingDate = bookingDate.substr(0, bookingDate.length()-1); // Remove newline
    }
};

// Node for Linked List of Bookings
struct BookingNode {
    Booking booking;
    BookingNode* next;
    
    BookingNode(const Booking& b) : booking(b), next(nullptr) {}
};

// Node for Graph representing routes
struct RouteNode {
    int stationId;
    string stationName;
    double distance;
    RouteNode* next;
    
    RouteNode(int id, string name, double dist) : stationId(id), stationName(name), distance(dist), next(nullptr) {}
};

class TrainManagementSystem {
private:
    vector<Train> trains;
    BookingNode* bookingsHead;
    stack<int> cancellationStack; // For undo functionality
    queue<pair<int, string>> waitingList; // (userId, coachType)
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> scheduleQueue; // (priority, trainId)
    map<int, vector<RouteNode*>> graph; // Adjacency list for routes
    
public:
    TrainManagementSystem() : bookingsHead(nullptr) {}
    
    ~TrainManagementSystem() {
        // Clean up linked list memory
        while (bookingsHead != nullptr) {
            BookingNode* temp = bookingsHead;
            bookingsHead = bookingsHead->next;
            delete temp;
        }
        
        // Clean up graph memory
        for (auto& pair : graph) {
            while (pair.second.size() > 0) {
                RouteNode* node = pair.second.back();
                pair.second.pop_back();
                delete node;
            }
        }
    }
    
    // 1. Vector for train storage
    void addTrain(const Train& train) {
        trains.push_back(train);
        sort(trains.begin(), trains.end()); // Keep sorted for binary search
    }
    
    // 2. Binary search for train lookup
    int binarySearchTrain(int trainId) const {
        int left = 0, right = trains.size() - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (trains[mid].trainId == trainId) {
                return mid;
            } else if (trains[mid].trainId < trainId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // Not found
    }
    
    // 3. Linked list for bookings
    void addBooking(const Booking& booking) {
        BookingNode* newNode = new BookingNode(booking);
        newNode->next = bookingsHead;
        bookingsHead = newNode;
    }
    
    // 4. Stack for cancellation undo
    void addToCancellationStack(int bookingId) {
        cancellationStack.push(bookingId);
    }
    
    int popFromCancellationStack() {
        if (cancellationStack.empty()) {
            return -1;
        }
        int top = cancellationStack.top();
        cancellationStack.pop();
        return top;
    }
    
    // 5. Queue for waiting list
    void addToWaitingList(int userId, const string& coachType) {
        waitingList.push(make_pair(userId, coachType));
    }
    
    pair<int, string> removeFromWaitingList() {
        if (waitingList.empty()) {
            return make_pair(-1, "");
        }
        pair<int, string> front = waitingList.front();
        waitingList.pop();
        return front;
    }
    
    // 6. Priority queue for scheduling
    void addToScheduleQueue(int priority, int trainId) {
        scheduleQueue.push(make_pair(priority, trainId));
    }
    
    pair<int, int> getNextScheduledTrain() {
        if (scheduleQueue.empty()) {
            return make_pair(-1, -1);
        }
        pair<int, int> top = scheduleQueue.top();
        scheduleQueue.pop();
        return top;
    }
    
    // 7. Graph for routes
    void addRoute(int fromStationId, int toStationId, const string& stationName, double distance) {
        RouteNode* newNode = new RouteNode(toStationId, stationName, distance);
        graph[fromStationId].push_back(newNode);
    }
    
    // Display functions
    void displayTrains() const {
        cout << "=== TRAIN LIST ===" << endl;
        for (const auto& train : trains) {
            cout << "ID: " << train.trainId 
                 << ", Name: " << train.trainName
                 << ", From: " << train.fromStation
                 << ", To: " << train.toStation
                 << ", Departure: " << train.departureTime
                 << ", Arrival: " << train.arrivalTime
                 << ", Duration: " << train.durationMinutes << " mins"
                 << ", Fare: $" << fixed << setprecision(2) << train.baseFare << endl;
                 
            cout << "  Availability: ";
            for (const auto& avail : train.availability) {
                cout << avail.first << ":" << avail.second << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
    
    void displayBookings() const {
        cout << "=== BOOKING LIST ===" << endl;
        BookingNode* current = bookingsHead;
        int count = 0;
        while (current != nullptr) {
            cout << "Booking ID: " << current->booking.bookingId
                 << ", User ID: " << current->booking.userId
                 << ", Train ID: " << current->booking.trainId
                 << ", Passenger: " << current->booking.passengerName
                 << ", Coach: " << current->booking.coachType
                 << ", Seat: " << current->booking.seatNumber
                 << ", Status: " << current->booking.status
                 << ", Fare: $" << fixed << setprecision(2) << current->booking.totalFare << endl;
            current = current->next;
            count++;
        }
        if (count == 0) {
            cout << "No bookings found." << endl;
        }
        cout << endl;
    }
    
    void displayWaitingList() const {
        cout << "=== WAITING LIST ===" << endl;
        queue<pair<int, string>> temp = waitingList;
        int count = 0;
        while (!temp.empty()) {
            cout << "User ID: " << temp.front().first 
                 << ", Coach Type: " << temp.front().second << endl;
            temp.pop();
            count++;
        }
        if (count == 0) {
            cout << "No users in waiting list." << endl;
        }
        cout << endl;
    }
    
    void displayCancellationStack() const {
        cout << "=== CANCELLATION STACK ===" << endl;
        stack<int> temp = cancellationStack;
        int count = 0;
        while (!temp.empty()) {
            cout << "Booking ID: " << temp.top() << endl;
            temp.pop();
            count++;
        }
        if (count == 0) {
            cout << "No cancellations in stack." << endl;
        }
        cout << endl;
    }
    
    // Search trains by source and destination
    vector<Train> searchTrains(const string& from, const string& to) const {
        vector<Train> result;
        for (const auto& train : trains) {
            if (train.fromStation == from && train.toStation == to) {
                result.push_back(train);
            }
        }
        return result;
    }
    
    // Check seat availability for a specific train and class
    bool checkSeatAvailability(int trainId, const string& coachType) const {
        int idx = binarySearchTrain(trainId);
        if (idx == -1) return false;
        
        if (trains[idx].availability.find(coachType) != trains[idx].availability.end()) {
            return trains[idx].availability.at(coachType) > 0;
        }
        return false;
    }
    
    // Book a ticket
    bool bookTicket(int userId, int trainId, const string& passengerName, 
                   const string& berthPref, const string& coachType, double fare) {
        int trainIdx = binarySearchTrain(trainId);
        if (trainIdx == -1) {
            cout << "Train with ID " << trainId << " not found." << endl;
            return false;
        }
        
        if (trains[trainIdx].availability[coachType] > 0) {
            // Allocate seat
            trains[trainIdx].availability[coachType]--;
            
            // Generate booking ID (simple approach)
            static int bookingCounter = 1000;
            int bookingId = ++bookingCounter;
            
            // Create booking
            Booking newBooking(bookingId, userId, trainId, passengerName, 
                              berthPref, coachType, 
                              trains[trainIdx].availability[coachType], // Using remaining seats as seat number
                              "CONFIRMED", fare);
            
            addBooking(newBooking);
            cout << "Booking successful! Booking ID: " << bookingId << endl;
            return true;
        } else {
            // Add to waiting list
            addToWaitingList(userId, coachType);
            cout << "No seats available. Added to waiting list." << endl;
            return false;
        }
    }
    
    // Cancel a ticket
    bool cancelTicket(int bookingId) {
        BookingNode* current = bookingsHead;
        BookingNode* prev = nullptr;
        
        while (current != nullptr) {
            if (current->booking.bookingId == bookingId) {
                // Add to cancellation stack for undo functionality
                addToCancellationStack(bookingId);
                
                // Update train availability
                int trainIdx = binarySearchTrain(current->booking.trainId);
                if (trainIdx != -1) {
                    trains[trainIdx].availability[current->booking.coachType]++;
                }
                
                // Remove from linked list
                if (prev == nullptr) {
                    bookingsHead = current->next;
                } else {
                    prev->next = current->next;
                }
                
                delete current;
                cout << "Booking with ID " << bookingId << " cancelled successfully." << endl;
                return true;
            }
            prev = current;
            current = current->next;
        }
        
        cout << "Booking with ID " << bookingId << " not found." << endl;
        return false;
    }
    
    // Undo cancellation
    bool undoCancellation() {
        int bookingId = popFromCancellationStack();
        if (bookingId == -1) {
            cout << "No cancellations to undo." << endl;
            return false;
        }
        
        // Find the original booking details and restore it
        // In a real system, we'd have the original booking details stored somewhere
        cout << "Undid cancellation for booking ID: " << bookingId << endl;
        return true;
    }
    
    // Get train by ID
    Train* getTrainById(int trainId) {
        int idx = binarySearchTrain(trainId);
        if (idx != -1) {
            return &trains[idx];
        }
        return nullptr;
    }
};

// Command-line argument parser
void printUsage() {
    cout << "Usage: train_system [command] [arguments]" << endl;
    cout << "Commands:" << endl;
    cout << "  add_train <id> <name> <from> <to> <dep_time> <arr_time> <dur_min> <fare>" << endl;
    cout << "  search_trains <from> <to>" << endl;
    cout << "  book_ticket <user_id> <train_id> <passenger_name> <berth_pref> <coach_type> <fare>" << endl;
    cout << "  cancel_ticket <booking_id>" << endl;
    cout << "  undo_cancel" << endl;
    cout << "  add_to_waiting_list <user_id> <coach_type>" << endl;
    cout << "  display_trains" << endl;
    cout << "  display_bookings" << endl;
    cout << "  display_waiting_list" << endl;
    cout << "  display_cancellations" << endl;
    cout << "  check_availability <train_id> <coach_type>" << endl;
}

int main(int argc, char* argv[]) {
    TrainManagementSystem system;
    
    if (argc < 2) {
        printUsage();
        return 1;
    }
    
    string command = argv[1];
    
    if (command == "add_train" && argc == 9) {
        int id = stoi(argv[2]);
        string name = argv[3];
        string from = argv[4];
        string to = argv[5];
        string dep = argv[6];
        string arr = argv[7];
        int dur = stoi(argv[8]);
        double fare = stod(argv[9]);
        
        Train train(id, name, from, to, dep, arr, dur, fare);
        system.addTrain(train);
        cout << "Train added successfully!" << endl;
    }
    else if (command == "search_trains" && argc == 4) {
        string from = argv[2];
        string to = argv[3];
        
        // Adding extensive sample train data
        system.addTrain(Train(101, "Rajdhani Express", "New Delhi", "Mumbai", "08:00", "16:00", 480, 2500.00));
        system.addTrain(Train(102, "Shatabdi Express", "New Delhi", "Chandigarh", "06:00", "09:30", 210, 1200.00));
        system.addTrain(Train(103, "Duronto Express", "Mumbai", "New Delhi", "22:00", "08:00", 600, 3000.00));
        system.addTrain(Train(104, "Mumbai Mail", "Mumbai", "New Delhi", "21:30", "08:15", 645, 1800.00));
        system.addTrain(Train(105, "Kolkata Mail", "Howrah", "New Delhi", "18:00", "09:10", 910, 1600.00));
        system.addTrain(Train(106, "Chennai Mail", "Chennai", "New Delhi", "19:00", "12:20", 1040, 1750.00));
        system.addTrain(Train(107, "Bangalore Express", "Bangalore", "Mumbai", "20:45", "14:30", 1065, 1400.00));
        system.addTrain(Train(108, "Goa Express", "Mumbai", "Goa", "07:00", "13:45", 405, 1100.00));
        system.addTrain(Train(109, "Hyderabad Express", "Secunderabad", "Mumbai", "22:30", "08:15", 585, 1300.00));
        system.addTrain(Train(110, "Ahmedabad Express", "Mumbai", "Ahmedabad", "23:15", "06:30", 435, 900.00));
        system.addTrain(Train(111, "Pune Express", "Mumbai", "Pune", "06:30", "09:15", 165, 350.00));
        system.addTrain(Train(112, "Jaipur Express", "Delhi", "Jaipur", "23:45", "06:30", 405, 450.00));
        system.addTrain(Train(113, "Patna Express", "New Delhi", "Patna", "17:30", "08:15", 885, 1200.00));
        system.addTrain(Train(114, "Lucknow Express", "New Delhi", "Lucknow", "05:30", "12:15", 405, 750.00));
        system.addTrain(Train(115, "Varanasi Express", "New Delhi", "Varanasi", "20:15", "06:45", 630, 950.00));
        
        auto results = system.searchTrains(from, to);
        if (results.empty()) {
            cout << "No trains found from " << from << " to " << to << endl;
        } else {
            cout << "Trains from " << from << " to " << to << ":" << endl;
            for (const auto& train : results) {
                cout << "ID: " << train.trainId << ", Name: " << train.trainName 
                     << ", Departure: " << train.departureTime 
                     << ", Arrival: " << train.arrivalTime 
                     << ", Fare: $" << fixed << setprecision(2) << train.baseFare << endl;
            }
        }
    }
    else if (command == "book_ticket" && argc == 8) {
        int userId = stoi(argv[2]);
        int trainId = stoi(argv[3]);
        string passengerName = argv[4];
        string berthPref = argv[5];
        string coachType = argv[6];
        double fare = stod(argv[7]);
        
        // Add sample trains for booking
        system.addTrain(Train(101, "Rajdhani Express", "New Delhi", "Mumbai", "08:00", "16:00", 480, 2500.00));
        system.addTrain(Train(102, "Shatabdi Express", "New Delhi", "Chandigarh", "06:00", "09:30", 210, 1200.00));
        system.addTrain(Train(104, "Mumbai Mail", "Mumbai", "New Delhi", "21:30", "08:15", 645, 1800.00));
        system.addTrain(Train(105, "Kolkata Mail", "Howrah", "New Delhi", "18:00", "09:10", 910, 1600.00));
        system.addTrain(Train(106, "Chennai Mail", "Chennai", "New Delhi", "19:00", "12:20", 1040, 1750.00));
        system.addTrain(Train(107, "Bangalore Express", "Bangalore", "Mumbai", "20:45", "14:30", 1065, 1400.00));
        system.addTrain(Train(108, "Goa Express", "Mumbai", "Goa", "07:00", "13:45", 405, 1100.00));
        system.addTrain(Train(109, "Hyderabad Express", "Secunderabad", "Mumbai", "22:30", "08:15", 585, 1300.00));
        system.addTrain(Train(110, "Ahmedabad Express", "Mumbai", "Ahmedabad", "23:15", "06:30", 435, 900.00));
        
        bool success = system.bookTicket(userId, trainId, passengerName, berthPref, coachType, fare);
        if (success) {
            cout << "Ticket booked successfully!" << endl;
        } else {
            cout << "Failed to book ticket." << endl;
        }
    }
    else if (command == "cancel_ticket" && argc == 3) {
        int bookingId = stoi(argv[2]);
        system.cancelTicket(bookingId);
    }
    else if (command == "undo_cancel" && argc == 2) {
        system.undoCancellation();
    }
    else if (command == "add_to_waiting_list" && argc == 4) {
        int userId = stoi(argv[2]);
        string coachType = argv[3];
        system.addToWaitingList(userId, coachType);
        cout << "Added user " << userId << " to waiting list for " << coachType << endl;
    }
    else if (command == "display_trains" && argc == 2) {
        system.displayTrains();
    }
    else if (command == "display_bookings" && argc == 2) {
        system.displayBookings();
    }
    else if (command == "display_waiting_list" && argc == 2) {
        system.displayWaitingList();
    }
    else if (command == "display_cancellations" && argc == 2) {
        system.displayCancellationStack();
    }
    else if (command == "check_availability" && argc == 4) {
        int trainId = stoi(argv[2]);
        string coachType = argv[3];
        
        // Add sample trains
        system.addTrain(Train(101, "Rajdhani Express", "New Delhi", "Mumbai", "08:00", "16:00", 480, 2500.00));
        system.addTrain(Train(102, "Shatabdi Express", "New Delhi", "Chandigarh", "06:00", "09:30", 210, 1200.00));
        system.addTrain(Train(104, "Mumbai Mail", "Mumbai", "New Delhi", "21:30", "08:15", 645, 1800.00));
        system.addTrain(Train(105, "Kolkata Mail", "Howrah", "New Delhi", "18:00", "09:10", 910, 1600.00));
        system.addTrain(Train(106, "Chennai Mail", "Chennai", "New Delhi", "19:00", "12:20", 1040, 1750.00));
        system.addTrain(Train(107, "Bangalore Express", "Bangalore", "Mumbai", "20:45", "14:30", 1065, 1400.00));
        system.addTrain(Train(108, "Goa Express", "Mumbai", "Goa", "07:00", "13:45", 405, 1100.00));
        system.addTrain(Train(109, "Hyderabad Express", "Secunderabad", "Mumbai", "22:30", "08:15", 585, 1300.00));
        system.addTrain(Train(110, "Ahmedabad Express", "Mumbai", "Ahmedabad", "23:15", "06:30", 435, 900.00));
        
        bool available = system.checkSeatAvailability(trainId, coachType);
        cout << "Seat availability for train " << trainId << " in " << coachType << ": " 
             << (available ? "AVAILABLE" : "NOT AVAILABLE") << endl;
    }
    else {
        printUsage();
        return 1;
    }
    
    return 0;
}